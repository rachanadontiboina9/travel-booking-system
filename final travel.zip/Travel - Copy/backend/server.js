require("dotenv").config();
const express = require("express");
const cors = require("cors");
const connectDB = require("./config/db");

const app = express();
app.use(express.json());
app.use(cors());

// Connect to Database
connectDB();

// Import Routes
app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/travel", require("./routes/travelRoutes"));
app.use("/api/accommodations", require("./routes/accommodationRoutes"));
app.use("/api/emergency", require("./routes/emergencyRoutes"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
