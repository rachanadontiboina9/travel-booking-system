const express = require("express");
const Emergency = require("../models/Emergency");

const router = express.Router();

router.get("/", async (req, res) => {
    const emergencies = await Emergency.find();
    res.json(emergencies);
});

router.post("/", async (req, res) => {
    const emergency = new Emergency(req.body);
    await emergency.save();
    res.status(201).json(emergency);
});

module.exports = router;
