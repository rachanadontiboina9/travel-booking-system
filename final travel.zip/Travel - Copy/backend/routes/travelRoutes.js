const express = require("express");
const Travel = require("../models/Travel");

const router = express.Router();

// Get all travel options
router.get("/", async (req, res) => {
    const travels = await Travel.find();
    res.json(travels);
});

// Add a new travel destination
router.post("/", async (req, res) => {
    const travel = new Travel(req.body);
    await travel.save();
    res.status(201).json(travel);
});

module.exports = router;

