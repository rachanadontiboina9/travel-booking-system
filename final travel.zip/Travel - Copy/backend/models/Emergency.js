const mongoose = require("mongoose");

const EmergencySchema = new mongoose.Schema({
    service: String,
    contact_number: String,
    location: String,
});

module.exports = mongoose.model("Emergency", EmergencySchema);
