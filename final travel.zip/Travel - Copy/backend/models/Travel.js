const mongoose = require("mongoose");

const TravelSchema = new mongoose.Schema({
    destination: String,
    description: String,
    best_time_to_visit: String,
    transport_options: [String],
});

module.exports = mongoose.model("Travel", TravelSchema);
