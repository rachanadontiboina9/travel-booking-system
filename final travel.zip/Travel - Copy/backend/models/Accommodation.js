const mongoose = require("mongoose");

const AccommodationSchema = new mongoose.Schema({
    name: String,
    location: String,
    price: Number,
    amenities: [String],
});

module.exports = mongoose.model("Accommodation", AccommodationSchema);
